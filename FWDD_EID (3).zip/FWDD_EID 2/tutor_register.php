<?php
include 'components/connect.php';

if (isset($_COOKIE['user_id'])) {
    $user_id = $_COOKIE['user_id'];
} else {
    $user_id = '';
}

if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $number = $_POST['phone-number'];
    $years = $_POST['years'];
    $password = sha1($_POST['password']);
  
    $image = $_FILES['profile-picture']['name'];
    $ext = pathinfo($image, PATHINFO_EXTENSION);
    $rename = unique_id() . '.' . $ext;
    $image_size = $_FILES['profile-picture']['size'];
    $image_tmp_name = $_FILES['profile-picture']['tmp_name'];
    $image_folder = 'uploaded_files/' . $rename;
  
       $insert_details = $conn->prepare("INSERT INTO tutor( name, age, gender, email, phone_number, years, password, profile_picture) VALUES (?,?,?,?,?,?,?,?)");
    $insert_details->execute([ $name, $age, $gender, $email, $number, $years, $password, $rename]);
    
  
    
  }

?>

<!DOCTYPE html>
<html>

<head>
    <?php
    
    include 'components/admin_header.php';
    
    ?>
    <title>Register Accountant</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <style>
         body {
            font-family: Arial, sans-serif;
            font-size:18px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .content-box {
            background-color: white;
            box-shadow: 13px 13px 20px grey, -13px -13px 20px white;
            padding: 20px;
            margin: 50px auto;
            width: 80%;
            max-width: 800px;
            padding: 25px 50px;
            border-radius: 20px;
            
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        } 

        input[type="text"],
        textarea,
        input[type="file"] {
            padding: 12px 20px;
            margin: 8;

        } 

        .content-box {
            background-color: white;
            box-shadow: lightgray;
            padding: 20px;
            margin: 50px 50px;
            width: 80%;
            max-width: 800px;
            box-shadow: 13px 13px 20px grey, -13px -13px 20px white;
            border-radius: 25px;
        }

        .card {
            display:flex;
            align-items: center;
            justify-content:center;
        }

        h1 {
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
        } 

        input[type="text"],
        textarea,
        input[type="file"] {
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            width: 100%;
            display: inline-block;
        } 

        .form-control{
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            width: 100%;
            display: inline-block;
        }

        button[type="submit"],
        button[type="button"] {
            background-color: #008CBA;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 20px 30px 10px 0px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 8px;
            box-shadow: 3px 3px 5px grey, -3px -3px 8px white;
        } 

        button[type="submit"]:hover,
        button[type="button"]:hover {
            background-color: #006080;
        } 
    </style>
</head>
<body>
    <div class="card">
    <div class="content-box">
        <h1>Register Tutor</h1>
        <form method="post" action="" enctype="multipart/form-data">

            <div class="input-group mb-3">
                <input type="file" class="form-control" id="profile-picture" name="profile-picture">
            </div>

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name">
            </div>

            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" name="age" min="0" value="0" id="age">
            </div>

            <label for="gender" class="form-label">Gender</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" value="Male" id="flexRadioDefault1">
                <label class="form-check-label" for="flexRadioDefault1">
                    Male
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" value="Female" id="flexRadioDefault2" checked>
                <label class="form-check-label" for="flexRadioDefault2">
                    Female
                </label>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="text" class="form-control" id="email" name="email">
            </div>

            <div class="mb-3">
                <label for="phone-number" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="phone-number" name="phone-number">
            </div>

            <div class="mb-3">
                <label for="years" class="form-label">Years Of Experience</label>
                <input type="number" class="form-control" name="years" min="0" max="40" value="0" id="years">
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>

            <button type="submit" name="submit" class="btn btn-success">Submit</button>
            <button type="button" class="btn btn-danger" onclick="location.href='home.php';">Cancel</button>
        </form>
    </div>
    </div>  
    <?php
    include 'components/footer.php';
    ?>
</body>

</html>
