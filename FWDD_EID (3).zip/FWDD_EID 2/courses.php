<?php

include_once ('components/connect.php');

if (isset($_COOKIE['user_id'])) {
   $user_id = $_COOKIE['user_id'];
} else {
   $user_id = '';

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Courses</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <style>
      body {
         margin: 0;
         padding: 0;
         font-family: 'Times New Roman', Times, serif;
         line-height: 1.5;
      }

      .course-info {
         display: flex;
         flex-wrap: wrap;
         justify-content: center;
         align-items: center;
         margin-top: 50px;
         border: 1px solid #ccc;
         border-radius: 20px;
         padding: 20px;
         background-color: white;
         box-shadow: 0px 3px 3px 3px lightgray;
         height: 400px;
      }

      .course-image {
         flex-basis: 30%;
         margin-right: 20px;
         background-color: grey;
         width: 380px;
         height: 380px;
      }

      .course-video {
         margin: 50px;
         align-items: center;
         display: flex;
         justify-content: center;

      }

      .course-details {
         flex-basis: 60%;
      }

      .course-name {
         font-size: 36px;
         margin: 0;
      }

      .course-description {
         font-size: 18px;
         margin-top: 10px;
      }

      .course-price {
         font-size: 24px;
         margin-top: 10px;
      }

      .course-content {
         margin: 0px 80px;
      }

      .tutor-profile {
         margin: 0px 80px;
      }

      button[type="button"] {
         background-color: #40AAD0;
         color: white;
         border: none;
         padding: 10px 20px;
         margin: 20px 10px;
         font-size: 16px;
         cursor: pointer;
         border-radius: 4px;
         float: right;
         height: 50px;
      }

      button[type="button"]:hover {
         background-color: #006080;
      }
   </style>
</head>

<body>

   <?php if(isset($_COOKIE['tutor_id'])){
      include_once('components/tutor_header.php');
   }else{
      include_once('components/user_header.php');
   }  ?>

   <!-- courses section starts  -->

   <section class="courses">

      <h1 class="heading">All Courses</h1>
      <?php
         $sql = "SELECT * FROM course";
         $result = $conn->query($sql);
         
         if ($result->rowCount() > 0) {
             // output data of each row
             foreach($result as $row) {?>
                 <div class="course-info">
            <img class="course-image" src="<?php echo $row['course_picture']; ?>" alt="Math Course">
            <div class="course-details">
               <h1 class="course-name"><?php echo $row['course_name']; ?></h1>
               <p class="course-description"><?php echo $row['description']; ?></p>
               <p class="course-price"><?php echo $row['instructor_name']; ?></p>
               <p class="course-price"><?php echo $row['price']; ?></p>
               <button type="button"><a href="tutorcourse.php?id=<?php echo $row['id']; ?>" class="enroll-button">Enroll Now</a></button>
               <?php if(isset($_COOKIE['tutor_id'])){?>
               <button type="button"><a href="tutor/courses_editing.php?id=<?php echo $row['id']; ?>" class="edit-button">Edit Course</a></button>
                  <?php
                  }
                  ?>
               </div>
         </div>
             <?php
               }
         } else {
             echo "0 results";
         }
      ?>


   </section>

   <!-- courses section ends -->


   <?php include 'components/footer.php'; ?>

   <!-- custom js file link  -->
   <script src="js/script.js"></script>

</body>

</html>