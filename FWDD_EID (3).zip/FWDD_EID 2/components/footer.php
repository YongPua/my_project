<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>EID</span> | all rights reserved!

</footer>