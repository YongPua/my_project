<?php

include '../components/connect.php';
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$getCourse = $conn->prepare("SELECT * FROM `course` WHERE id = ?");
	$getCourse->execute([$id]);
}

if (isset($_COOKIE['tutor_id'])) {
	$tutor_id = $_COOKIE['tutor_id'];
} else {
	$tutor_id = '';
	$tutor_id = header("location: ../tutor_login.php");
}

// Insert data into database
if (isset($_POST['submit'])) {
	// Get form data
	$coursename = $_POST['course-name'];
	$coursename = filter_var($coursename, FILTER_SANITIZE_STRING);
	$description = $_POST['description'];
	$description = filter_var($description, FILTER_SANITIZE_STRING);
	$youLearn = $_POST['you-learn'];
	$youLearn = filter_var($youLearn, FILTER_SANITIZE_STRING);
	$instructorName = $_POST['instructor-name'];
	$instructorName = filter_var($instructorName, FILTER_SANITIZE_STRING);

	// Upload course picture
	$fileName = "";
	if (isset($_FILES["course-picture"])) {
		$file = $_FILES["course-picture"]["name"];
		$file = filter_var($file, FILTER_SANITIZE_STRING);
		$fileName = pathinfo($file, PATHINFO_BASENAME);
		$file_folder = '../uploaded_files/' . $fileName;
		$file_tmp_name = $_FILES["course-picture"]["tmp_name"];
		move_uploaded_file($file_tmp_name, $file_folder);
	}

	// Upload course content
	$contentName = "";
	if (isset($_FILES["content"])) {
		$content = $_FILES["content"]["name"];
		$content = filter_var($content, FILTER_SANITIZE_STRING);
		$contentName = pathinfo($content, PATHINFO_BASENAME);
		$content_folder = '../uploaded_files/' . $contentName;
		$content_tmp_name = $_FILES["content"]["tmp_name"];
		move_uploaded_file($content_tmp_name, $content_folder);
	}
	$addcourses = $conn->prepare("UPDATE course SET course_picture=?, course_name=?, description=?, content=?, you_learn=?, instructor_name=? WHERE id=?");

	move_uploaded_file($file_tmp_name, "path/to/folder/" . $fileName);
	move_uploaded_file($content_tmp_name, "path/to/folder/" . $contentName);

	$addcourses->execute([$fileName, $coursename, $description, $contentName, $youLearn, $instructorName, $_GET['id']]);


	$message[] = 'New course created!';
	header("location: ../courses.php");
}
?>


<!DOCTYPE html>
<html>

<head>
	<title>Course Editing</title>
	<style>
		body {
			font-family: Arial, sans-serif;
		}

		.container {
			max-width: 800px;
			margin: 0 auto;
			padding: 20px;
		}

		.content-box {
			background-color: white;
			box-shadow: 13px 13px 20px grey, -13px -13px 20px white;
			padding: 20px;
			margin: 50px auto;
			width: 80%;
			max-width: 800px;
			padding: 25px 50px;
			border-radius: 20px;
		}

		h1 {
			text-align: center;
		}

		label {
			display: block;
			margin-bottom: 10px;
		}

		input[type="text"],
		textarea,
		input[type="file"] {
			padding: 12px 20px;
			margin: 8
		}

		.content-box {
			background-color: white;
			box-shadow: lightgray;
			padding: 20px;
			margin: 50px auto;
			width: 80%;
			max-width: 800px;
			box-shadow: 13px 13px 20px grey, -13px -13px 20px white;
			border-radius: 25px;
		}

		h1 {
			text-align: center;
		}

		label {
			display: block;
			margin-bottom: 10px;
		}

		input[type="text"],
		textarea,
		input[type="file"] {
			padding: 12px 20px;
			margin: 8px 0;
			box-sizing: border-box;
			border: 2px solid #ccc;
			border-radius: 4px;
			width: 100%;
			display: inline-block;
		}

		button[type="submit"],
		button[type="button"] {
			background-color: #008CBA;
			color: white;
			border: none;
			padding: 10px 20px;
			margin: 20px -230px 10px 280px;
			font-size: 16px;
			cursor: pointer;
			border-radius: 8px;
			box-shadow: 3px 3px 5px grey, -3px -3px 8px white;
		}

		button[type="submit"]:hover,
		button[type="button"]:hover {
			background-color: #006080;
		}
	</style>
	<!-- font awesome cdn link  -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

	<!-- custom css file link  -->
	<link rel="stylesheet" href="../css/style.css">
</head>

<body>
	<?php include('../components/tutor_header.php'); ?>
	<form method="POST" action="" enctype="multipart/form-data">
		<?php
		foreach ($getCourse as $row) {
		?>
			<div class="content-box">
				<h1>Course Editing</h1>
				<img class="course-image" src="<?php echo $row['course_picture']; ?>" alt="Math Course" width="100%" height="100%">
				<label for="course-picture">Course Picture:</label>
				<input type="file" id="course-picture" name="course-picture"><br>

				<label for="course-name">Course Name:</label>
				<input type="text" id="course-name" name="course-name" placeholder="Enter course name" value="<?php echo $row['course_name']; ?>" required><br>

				<label for="description">Description:</label>
				<textarea id="description" name="description" placeholder="Enter course description" required><?php echo $row['description']; ?></textarea><br>

				<label for="content">Content:</label>
				<input type="file" id="content" name="content"><br>

				<label for="you-learn">You'll Learn:</label>
				<textarea id="you-learn" name="you-learn" placeholder="Enter what students will learn" required><?php echo $row['you_learn']; ?></textarea><br>

				<label for="instructor-name">Instructor Name:</label>
				<input type="text" id="instructor-name" name="instructor-name" value="<?php echo $row['instructor_name']; ?>" required><br>

				<button type="submit" name="submit" value="submit">Upload</button>
				<button type="button" onclick="location.href='../courses.php';">Cancel</button>
			</div>
		<?php
		}
		?>
	</form>
</body>

</html>