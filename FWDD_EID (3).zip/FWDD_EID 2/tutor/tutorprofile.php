<?php

include '../components/connect.php';

if(isset($_COOKIE['tutor_id'])){
	$tutor_id = $_COOKIE['tutor_id'];
 }else{
	$tutor_id = '';
 }
$myUser = $conn->prepare("SELECT * FROM tutor WHERE id = ?");
$myUser->execute([$tutor_id]);
$user = $myUser->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['submit'])){

	$select_user = $conn->prepare("SELECT * FROM `tutor` WHERE id = ?");
	$select_user->execute([$tutor_id]);
	$fetch_user = $select_user->fetch(PDO::FETCH_ASSOC);
 
	$name = $_POST['name'];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	$email = $_POST['email'];
	$email = filter_var($email, FILTER_SANITIZE_STRING);
 
	$empty_pass = 'da39a3ee5e6b4b0d3255bfef95601890afd80709';
	$old_pass = ($_POST['old_pass']);
	$old_pass = filter_var($old_pass, FILTER_SANITIZE_STRING);
	$new_pass = ($_POST['new_pass']);
	$new_pass = filter_var($new_pass, FILTER_SANITIZE_STRING);
	$cpass = ($_POST['cpass']);
	$cpass = filter_var($cpass, FILTER_SANITIZE_STRING);
 
	$select_name = $conn->prepare("SELECT * FROM `tutor` WHERE name = ?");
	$select_name->execute([$name]);
	$select_email = $conn->prepare("SELECT * FROM `tutor` WHERE email = ?");
	$select_email->execute([$email]);
 
	if($old_pass != $empty_pass){
	   if($old_pass != $prev_pass){
		  $message[] = 'Old password not matched!';
	   }else{
		  if($new_pass != $cpass){
			 $message[] = 'Confirm password not matched!';
		  }else{
			 if(!empty($name)){
				$update_name = $conn->prepare("UPDATE `tutor` SET name = ? WHERE id = ?");
				$update_name->execute([$name, $tutor_id]);
				$message[] = 'Name updated successfully!';
			 }else{
				if(!empty($email)){
				   $update_email = $conn->prepare("UPDATE `tutor` SET email = ? WHERE id = ?");
				   $update_email->execute([$email, $tutor_id]);
				   $message[] = 'Email updated successfully!';
				}
			 }
		  }
			 if($new_pass != $empty_pass){
				$update_pass = $conn->prepare("UPDATE `users` SET password = ? WHERE id = ?");
				$update_pass->execute([$cpass, $user_id]);
				$message[] = 'Password updated successfully!';
 
				
			 }else{
				$message[] = 'Please enter a new password!';
			 }
		  }
	   }
	}
?>



<!DOCTYPE html>
<html>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<head>
	<!-- font awesome cdn link  -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

	<!-- custom css file link  -->
	<link rel="stylesheet" href="../css/tutor_style.css">

	<?php include '../components/tutor_header.php'; ?>

	<title>Profile</title>
	<style>
		.content-box {
			background-color: white;
			box-shadow: 0px 5px 5px 5px lightgray;
			padding: 20px;
			margin: 50px auto;
			width: 80%;
			max-width: 800px;
			height: 680px;
			font-size:16px;
		}

		h1 {
			text-align: center;
		}

		label {
			display: block;
			margin-bottom: 10px;
			font-weight: bold;
		}

		.profile-pic {
			display: inline-block;
			vertical-align: middle;
			width: 150px;
			height: 150px;
			border-radius: 50%;
			margin-right: 20px;
		}

		.content {
			display: inline-block;
			vertical-align: middle;
			line-height: 1.5;
		}

		button[type="button"] {
			background-color: #40AAD0;
			color: white;
			border: none;
			padding: 10px 20px;
			margin: 20px 10px;
			font-size: 16px;
			cursor: pointer;
			border-radius: 4px;
			float: right;
			height:50px;
		}

		button[type="button"]:hover {
			background-color: #006080;
		}

		.form-popup {
			display: none;
			position: fixed;
			bottom: 0;
			right: 15px;
			border: 3px solid #f1f1f1;
			z-index: 9;
			background-color: white;
			padding: 20px;
			max-width: 600px;
			width: 80%;
		}

		.form-popup label {
			font-weight: normal;
		}

		.form-popup input[type="text"], .form-popup textarea {
			width: 100%;
			margin: 8px 0;
			padding: 12px 20px;
			box-sizing: border-box;
			border: 2px solid #ccc;
			border-radius: 4px;
			resize: vertical;
			display: inline-block;
		}

		.form-popup button[type="submit"], .form-popup button[type="button"] {
			background-color: #40AAD0;
			color: white;
			border: none;
			padding: 10px 20px;
			margin: 10px;
			font-size: 16px;
			cursor: pointer;
			border-radius: 4px;
			float: right;
		}

		.form-popup button[type="submit"]:hover, .form-popup button[type="button"]:hover {
			background-color: #006080;
		}

        #edit-form {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 30px;
            border: 1px solid black;
            z-index: 9999;
            display: none;
			border-radius: 20px;
			width: 400px;
			font-size:16px;
          }
          
          #edit-form h2 {
            margin-top: 0;
          }
          
          #edit-form label {
            display: block;
            margin-bottom: 5px;
          }
          
          #edit-form input,
          #edit-profile-form textarea {
            display: block;
            margin-bottom: 20px;
            width: 100%;
			height:25px;
          }
          
          #edit-form button {
            margin-right: 10px;
          }

		  #ps-form {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 30px;
            border: 1px solid black;
            z-index: 9999;
            display: none;
			border-radius: 20px;
			width: 400px;
			font-size:16px;
          }
          
          #ps-form h2 {
            margin-top: 0;
          }
          
          #ps-form label {
            display: block;
            margin-bottom: 5px;
          }
          
          #ps-form input,
          #edit-profile-form textarea {
            display: block;
            margin-bottom: 20px;
            width: 100%;
			height:35px;
          }
          
          #ps-form button {
            margin-right: 10px;
          }
          
		  .profile-image {
            background-color: #40AAD0;
            width:150px;
			height:150px;
			border-radius:50px;
			padding: 15px 15px;
          }

		  .profile-image img {
            width: 120px;
            height: 120px;
            border-radius: 30px;
            object-fit: cover;
			padding: 2px 2px;
          }
	</style>
</head>
<body>
	<div class="content-box">
		<div lass="content">
			<h1>PROFILE</h1>
			<div class="profile-image">
                <img src="profileimg.png" style="filter: brightness(0) invert(1);" alt="Profile Image">
              </div><br>

			<label for="name">Name:</label>
			<p id="name"><?php echo $user['name']; ?></p>

			<label for="email">Email:</label>
			<p id="email"><?php echo $user['email']; ?></p>

			<p>Kuala Lumpur, Malaysia</p>
			<p>Professional Certification in Advanced Special Education (ADISE)</p>
			<p>Math & Science Tutor</p>
			<br>

			<p><b>Bio:</b></p>
			<p>As a teaching student with disabilities tutor in math and science, I am committed to helping students with diverse needs reach their full potential. With a strong academic background in math and science, and experience working with students with disabilities, I am equipped to provide individualized support to help students overcome their challenges and achieve their academic goals. I strive to create a supportive and inclusive learning environment, and am dedicated to fostering a love of learning in all of my students.</p>

			<button id="edit-button" type="button" onclick="openEditForm()">Edit</button>
			<button id="ps-button" type="button" onclick="openPasswordForm()"><i class='fas fa-lock'></i></button>
			
		</div>
	</div>

    <div id="edit-form" class="popup" style="display:none">
		<form action="" method="POST" enctype="multipart/form-data">
			<h2>Edit Profile</h2>
			<label for="name">Name:</label>
			<input type="text" id="name" name="name" placeholder="Enter your name"><br>
			<label for="phone">Phone:</label>
			<input id="phone" name="phone" placeholder="Enter your phone number"><br>

			<button id="save-btn" type="button" onclick="showmessage()">Save</button>
			<button id="cancel-btn" type="button" onclick="closeForm()">Cancel</button>
		</form>
	</div>

	<div id="ps-form" class="popup" style="display:none">
		<form action="" method="POST" enctype="multipart/form-data">
			<p>Current Password <span>*</span><i class="fa-solid fa-eye" id="oeye"></i></p>
			<input type="password" name="old_pass" id="opassword" placeholder="Enter your old password" maxlength="50" required class="box" >
			<p>New Password <span>*</span><i class="fa-solid fa-eye" id="eye"></i></p>
			<input type="password" name="new_pass" id="password" placeholder="Enter your new password" maxlength="50" required class="box" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password must contain at least one number, one uppercase letter, one lowercase letter, and be at least 8 characters long">
			<p>Confirm Password <span>*</span><i class="fa-solid fa-eye" id="ceye"></i></p>
			<input type="password" name="cpass" id="cpassord"placeholder="Confirm your new password" maxlength="50" required class="box" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password must contain at least one number, one uppercase letter, one lowercase letter, and be at least 8 characters long">
			<button id="save-btn" type="button" onclick="showmessage()">Save</button>
			<button id="cancel-btn" type="button" onclick="closeForm()">Cancel</button>
		</form>
	</div>
      
	<script>
		
			// Get the edit button and the edit form
			const editButton = document.getElementById('edit-button');
			const editForm = document.getElementById('edit-form');
			
			const editButton2 = document.getElementById('ps-button');
			const editForm2 = document.getElementById('ps-form');
		  
			// Get the cancel button and add an event listener to close the form when clicked
			const cancelButton = document.querySelector('#edit-form button[id="cancel-btn"]');
			cancelButton.addEventListener('click', () => {
			  editForm.style.display = 'none';
			});
		    
			// Add an event listener to the edit button to show the edit form when clicked
			editButton.addEventListener('click', () => {
			  editForm.style.display = 'block';
			});		
			
			editButton2.addEventListener('click', () => {
				editForm2.style.display = 'block';
			  });	
			
			const cancelButton2 = document.querySelector('#ps-form button[id="cancel-btn"]');
			cancelButton2.addEventListener('click', () => {
			  editForm2.style.display = 'none';
			});
	
			const passwordInput = document.querySelector("#password");
			const eye = document.querySelector("#eye");

			eye.addEventListener("click", function(){
			this.classList.toggle("fa-eye-slash");
			const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
			passwordInput.setAttribute("type", type);
			})

			const passwordConfirm = document.querySelector("#cpassword")
			const ceye = document.querySelector("#ceye")

			ceye.addEventListener("click", function(){
			this.classList.toggle("fa-eye-slash");
			const type = passwordConfirm.getAttribute("type") === "password" ? "text" : "password";
			passwordConfirm.setAttribute("type", type)
			})

			const passwordOld = document.querySelector("#opassword")
			const oeye = document.querySelector("#oeye")

			oeye.addEventListener("click", function(){
			this.classList.toggle("fa-eye-slash");
			const type = passwordOld.getAttribute("type") === "password" ? "text" : "password";
			passwordOld.setAttribute("type", type)
			})

			const form = document.querySelector('#ps-form');
      		const submitBtn = document.querySelector('#save-btn');

			submitBtn.addEventListener('click', (event) => {
				event.preventDefault();
				alert('Form submitted successfully!');
				form.reset();
			});
		
		
			  
	</script>