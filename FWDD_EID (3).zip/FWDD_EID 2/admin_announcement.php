<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<?php include 'components/admin_header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin_Announcement</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
	<style>
		* {
		  box-sizing: border-box;
		}

		.announcement_container {
		  max-width: 800px;
		  margin: 0 auto;
		  padding: 20px;
		}

		#text_announcement {
		  text-align: center;
		  margin-bottom: 20px;
		  font-size: 25px;
		}

		#announcement-form {
		  display: flex;
		  flex-direction: column;
		  align-items: center;
		  margin-bottom: 20px;
		}

		#lbl_announce {
		  margin-bottom: 10px;
		  font-size: 16px;
		}

		#announcement-text {
		  padding: 10px;
		  font-size: 1rem;
		  border-radius: 5px;
		  border: 1px solid #ccc;
		  margin-bottom: 10px;
		  width: 100%;
		}

		#announce_submit {
		  padding: 10px 20px;
		  font-size: 1.3rem;
		  border-radius: 5px;
		  border: none;
		  background-color: #008CBA;
		  color: #fff;
		  cursor: pointer;
		  transition: background-color 0.3s ease;
		}

		#announce_submit:hover {
		  background-color: #006B87;
		}

		#announcement-list {
		  display: flex;
		  flex-direction: column;
		  margin-bottom: 20px;

		  /* Add responsive styles */
		  @media only screen and (max-width: 600px) {
			width: 100%;
		  }
		}

		.announcement {
		  display: flex;
		  justify-content: space-between;
		  align-items: center;  
		  background-color: #f9f9f9;
		  padding: 10px;
		  font-size: 15px;
		  margin-bottom: 10px;
		  border-radius: 5px;
		  word-wrap: break-word; /* Wrap the text within the container */
		  word-break: break-word; /* Break the text when necessary */


		  /* Add responsive styles */
		  @media only screen and (max-width: 600px) {
			flex-direction: column;
			align-items: center;
			text-align: center;
		  }
		}

		.edit-button {
		  padding: 5px 10px;
		  background-color: #0EA70A;
		  color: #fff;
		  border: none;
		  border-radius: 5px;
		  cursor: pointer;
		  margin-right: 20px;
		  min-width:100px;
		}

		.edit-button:hover {
		  background-color: #146412;
		}

		#announcement-text::placeholder {
		  font-size: 15px;
		}

	</style>
  </head>
  <body>



	<!-- about section starts  -->
	<section>
		<div class="announcement_container">
		  <h1 id="text_announcement">Upload Announcements</h1>
		  <form id="announcement-form">
			<input type="text" id="announcement-text" placeholder="Enter your announcement here" style="font-size: 15px;"/>
			<button id="announce_submit" type="submit">Submit</button>
		  </form>
		  <label id="lbl_announce" for="announcement-text">Announcements:</label>
		  <div style="height:20px;"></div>
		  <div id="announcement-list"></div>
		</div>
		<script src="script.js"></script>
		<script>
			const announcementForm = document.getElementById('announcement-form');
			const announcementInput = document.getElementById('announcement-text');
			const announcementList = document.getElementById('announcement-list');

			announcementForm.addEventListener('submit', (event) => {
			  event.preventDefault();
			  const announcement = announcementInput.value.trim();
			  if (announcement !== '') {
				const newAnnouncement = document.createElement('div');
				newAnnouncement.classList.add('announcement');

				// create the announcement text element
				const announcementText = document.createElement('span');
				announcementText.textContent = announcement;
				newAnnouncement.appendChild(announcementText);

				// create the edit button element
					const editButton = document.createElement('button');
					editButton.textContent = 'Edit';
					editButton.classList.add('edit-button');
					editButton.addEventListener('click', () => {
					  announcementInput.value = announcementText.textContent;
					  newAnnouncement.remove();
					});
					newAnnouncement.appendChild(editButton);		


				announcementList.appendChild(newAnnouncement);
				announcementInput.value = '';
			  }
			});

		</script>
	</section>









<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>