<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
<style>
	.map-responsive{
		overflow:hidden;
		padding-bottom:56.25%;
		position:relative;
		height:0;
	}
	.map-responsive iframe{
		left:0;
		top:0;
		height:100%;
		width:100%;
		position:absolute;
	}
	
	*{
	  margin: 0;
	  padding: 0;
	  -webkit-box-sizing: border-box;
			  box-sizing: border-box;
	}

	.wrapper{
	  width: 90%;
	  margin: 0 auto;
	  max-width: 80rem;
	}

	.cols{
	  display: -webkit-box;
	  display: -ms-flexbox;
	  display: flex;
	  -ms-flex-wrap: wrap;
		  flex-wrap: wrap;
	  -webkit-box-pack: center;
		  -ms-flex-pack: center;
			  justify-content: center;
	}

	.col{
	  width: calc(25% - 2rem);
	  margin: 1rem;
	  cursor: pointer;
	}

	.container{
	  -webkit-transform-style: preserve-3d;
			  transform-style: preserve-3d;
	  -webkit-perspective: 1000px;
			  perspective: 1000px;
	}

	.front,
	.back{
	  background-size: cover;
	  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.25);
	  border-radius: 10px;
	  background-position: center;
	  -webkit-transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	  transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	  -o-transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	  transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	  transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1), -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	  -webkit-backface-visibility: hidden;
			  backface-visibility: hidden;
	  text-align: center;
	  min-height: 280px;
	  height: auto;
	  border-radius: 10px;
	  color: #fff;
	  font-size: 1.7rem;
	}

	.back{
	  background: #cedce7;
	  background: -webkit-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
	  background: -o-linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
	  background: linear-gradient(45deg,  #cedce7 0%,#596a72 100%);
	}

	.front:after{
	  position: absolute;
		top: 0;
		left: 0;
		z-index: 1;
		width: 100%;
		height: 100%;
		content: '';
		display: block;
		opacity: .6;
		background-color: #000;
		-webkit-backface-visibility: hidden;
				backface-visibility: hidden;
		border-radius: 10px;
	}
	.container:hover .front,
	.container:hover .back{
		-webkit-transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
		transition: -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
		-o-transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
		transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
		transition: transform .7s cubic-bezier(0.4, 0.2, 0.2, 1), -webkit-transform .7s cubic-bezier(0.4, 0.2, 0.2, 1);
	}

	.back{
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
	}

	.inner{
		-webkit-transform: translateY(-50%) translateZ(60px) scale(0.94);
				transform: translateY(-50%) translateZ(60px) scale(0.94);
		top: 50%;
		position: absolute;
		left: 0;
		width: 100%;
		padding: 2rem;
		-webkit-box-sizing: border-box;
				box-sizing: border-box;
		outline: 1px solid transparent;
		-webkit-perspective: inherit;
				perspective: inherit;
		z-index: 2;
	}

	.container .back{
		-webkit-transform: rotateY(180deg);
				transform: rotateY(180deg);
		-webkit-transform-style: preserve-3d;
				transform-style: preserve-3d;
	}

	.container .front{
		-webkit-transform: rotateY(0deg);
				transform: rotateY(0deg);
		-webkit-transform-style: preserve-3d;
				transform-style: preserve-3d;
	}

	.container:hover .back{
	  -webkit-transform: rotateY(0deg);
			  transform: rotateY(0deg);
	  -webkit-transform-style: preserve-3d;
			  transform-style: preserve-3d;
	}

	.container:hover .front{
	  -webkit-transform: rotateY(-180deg);
			  transform: rotateY(-180deg);
	  -webkit-transform-style: preserve-3d;
			  transform-style: preserve-3d;
	}

	.front .inner p{
	  font-size: 2rem;
	  margin-bottom: 2rem;
	  position: relative;
	}

	.front .inner p:after{
	  content: '';
	  width: 4rem;
	  height: 2px;
	  position: absolute;
	  background: #C6D4DF;
	  display: block;
	  left: 0;
	  right: 0;
	  margin: 0 auto;
	  bottom: -.75rem;
	}

	.front .inner span{
	  color: rgba(255,255,255,0.7);
	  font-family: 'Montserrat';
	  font-weight: 300;
	}

	@media screen and (max-width: 64rem){
	  .col{
		width: calc(33.333333% - 2rem);
	  }
	}

	@media screen and (max-width: 48rem){
	  .col{
		width: calc(50% - 2rem);
	  }
	}

	@media screen and (max-width: 32rem){
	  .col{
		width: 100%;
		margin: 0 0 2rem 0;
	  }
	}

</style>
</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">

      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3>Why Choose EID?</h3>
         <p>EID provides an equitable education for every student and helps individuals develop critical thinking skills, problem-solving abilities, and the ability to communicate effectively. 
		 EID can also help individuals gain knowledge about a wide range of subjects</p>
         <a href="courses.php" class="inline-btn">Our Courses</a>
      </div>

   </div>

   <div class="box-container">

      <div class="box">
         <i class="fas fa-graduation-cap"></i>
         <div>
            <span>Online Courses</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-user-graduate"></i>
         <div>
            <span>Brilliants Students</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-chalkboard-user"></i>
         <div>
            <span>Expert Teachers</span>
         </div>
      </div>

      <!--<div class="box">
         <i class="fas fa-briefcase"></i>
         <div>
            <span>Job Placement</span>
         </div>
      </div> -->

   </div>

</section>

<!-- about section ends -->

<!-- reviews section starts  -->

<section class="reviews">

   <h1 class="heading">student's reviews</h1>

   <div class="box-container">

      <div class="box">
         <p>The teacher was also very accommodating and provided additional resources to support my learning.</p>
         <div class="user">
            <img src="images/pic-2.jpg" alt="">
            <div>
               <h3>Samantha Carter</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>The rewatch option allowed me to fully engage with the course content and stay on track with my homework.</p>
         <div class="user">
            <img src="images/pic-3.jpg" alt="">
            <div>
               <h3>Adam Johnson</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>The teacher provided materials in a variety of formats,
		 which helped me to engage with the content more effectively.</p>
         <div class="user">
            <img src="images/pic-4.jpg" alt="">
            <div>
               <h3>Nicholas Lee</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>I was able to navigate the course content easily using my assistive technology.
			very responsive to my needs and provided additional resource.</p>
         <div class="user">
            <img src="images/pic-5.jpg" alt="">
            <div>
               <h3>Victoria Nguyen</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>The instructor provided a variety of materials and formats to support learners with diverse needs,
		 and the course content was easy to understand and engage with.</p>
         <div class="user">
            <img src="images/pic-6.jpg" alt="">
            <div>
               <h3>Benjamin Scott</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>I was impressed with the quality of the e-learning platform used for this course. 
		 It was easy to navigate and the multimedia content was well-designed and engaging.</p>
         <div class="user">
            <img src="images/pic-7.jpg" alt="">
            <div>
               <h3>Elizabeth Patel</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

   </div>

</section>

<section>
	<h1 class="heading">EID Aims</h1>
	<div class="wrapper">
	  <div class="cols">
		  <div class="col" ontouchstart="this.classList.toggle('hover');">
			<div class="container">
			  <div class="front" style="background-image: url(https://online.vu.edu.au/sites/default/files/field/image/Keypath---VU-MBA-Skyscraper-Article-1--What-is-Global-Corporate-Social-Responsibility---Good-and-Bad-Examples_header_0.png)">
				<div class="inner">
				  <p>Responsibility</p>
				</div>
			  </div>
			  <div class="back">
				<div class="inner">
				  <p>EID passionate about helping students to achieve their full potential</p>
				</div>
			  </div>
			</div>
		  </div>
		  <div class="col" ontouchstart="this.classList.toggle('hover');">
			<div class="container">
			  <div class="front" style="background-image: url(https://blog.vantagecircle.com/content/images/2019/06/Communication-skills-in-the-workplace.png)">
				<div class="inner">
				  <p>Patience</p>
				</div>
			  </div>
			  <div class="back">
				<div class="inner">
				  <p>EID staffs communicate effectively with students, colleagues, and parents.</p>
				</div>
			  </div>
			</div>
		  </div>
		  <div class="col" ontouchstart="this.classList.toggle('hover');">
			<div class="container">
			  <div class="front" style="background-image: url(https://images.pexels.com/photos/34546/sunset-lake-landscape-summer.jpg?w=1260&h=750&dpr=2&auto=compress&cs=tinysrgb)">
				<div class="inner">
				  <p>Knowledgeable</p>
				</div>
			  </div>
			  <div class="back">
				<div class="inner">
				  <p>EID expert teachers provide accurate and up-to-date information to their students.</p>
				</div>
			  </div>
			</div>
		  </div>         
		</div>
	 </div>
</section>

<section>
	<h1 class="heading"><br>Our Location</h1>

	<div class="map-responsive">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.146627454418!2d101.69837271475707!3d3.055405697774977!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4abb795025d9%3A0x1c37182a714ba968!2z5Lqa5aSq56eR5oqA5aSn5a2m!5e0!3m2!1szh-CN!2smy!4v1676125633576!5m2!1szh-CN!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
</section>

<!-- reviews section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>