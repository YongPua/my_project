<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
   setcookie('user_id', '', time() - 1, '/');
}

$select_likes = $conn->prepare("SELECT * FROM `likes` WHERE user_id = ?");
$select_likes->execute([$user_id]);
$total_likes = $select_likes->rowCount();

$select_comments = $conn->prepare("SELECT * FROM `comments` WHERE user_id = ?");
$select_comments->execute([$user_id]);
$total_comments = $select_comments->rowCount();

$select_bookmark = $conn->prepare("SELECT * FROM `bookmark` WHERE user_id = ?");
$select_bookmark->execute([$user_id]);
$total_bookmarked = $select_bookmark->rowCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

<style>
.responsive {
  width: 100%;
  max-width: 500px;
}

/* Create two equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 310px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}

#home_intro:hover,home_intro:active{color:#086D79;}

@import url('https://fonts.googleapis.com/css?family=Quicksand:400,700');

/* Design */
*,
*::before,
*::after {
  box-sizing: border-box;
}

.main{
  max-width: 1200px;
  margin: 0 auto;
}

.img_headings {
  height: auto;
  max-width: 100%;
  vertical-align: middle;
}

.cards {
  display: flex;
  flex-wrap: wrap;
  list-style: none;
  margin: 0;
  padding: 0;
}

.cards_item {
  display: flex;
  padding: 1rem;
}

@media (min-width: 40rem) {
  .cards_item {
    width: 20%;
  }
}

@media (min-width: 56rem) {
  .cards_item {
    width: 33.3333%;
  }
}

.card {
  background-color: white;
  border-radius: 0.25rem;
  box-shadow: 0 20px 40px -14px rgba(0, 0, 0, 0.25);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.card_content {
  padding: 1rem;
  background: linear-gradient(to bottom left, #91CFFA 30%, #9CFCB4 100%);
}

.card_title {
  color: var(--black);
  font-size: 2.0rem;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: capitalize;
  margin: 0px;
}

.card_text {
  color: var(--black);
  font-size: 1.7rem;
  line-height: 1.5;
  margin-bottom: 1.25rem;    
  font-weight: 400;
}

.map-responsive{
	overflow:hidden;
	padding-bottom:56.25%;
	position:relative;
	height:0;
}
.map-responsive iframe{
	left:0;
	top:0;
	height:100%;
	width:100%;
	position:absolute;
}

</style>

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- quick select section starts  -->

  
<section>
	<h1 class="heading">Welcome to EID Homepage</h1>

<div class="row">
  <div class="column" style="background-color:#CFD0D0;">
    <img src="images/home_img.jpeg" alt="Nature" class="responsive" width="480" height="280">
  </div>
  <div class="column" style="background-color:#CFD0D0;">
    <h2 style="color: 001A1D;font-size: 2.1rem;">E-LEARNING FOR INDIVIDUALS WITH DISABILITIES (EID)</h2>
    <p id="home_intro" style="font-size: 1.8rem;"><br>For students with disabilities to have enough time and space to study, the EID offers courses. 
	Math is the primary course that EID offers. In addition, students are free to watch the course videos 
	as many times as necessary after purchasing them. Students can avoid rushing to campus or driving between 
	classes by using e-learning, which allows them to remain in their familiar surroundings.</p>
	<div class="flex-btn" style="padding-top: .5rem;">
            <a href="about.php" class="option-btn">Learn More</a>
    </div>
  </div>
</div>
</section>


<section>
	<h1 class="heading"><br>Our Headings</h1>

<div class="main">
  <ul class="cards">
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=20"></div>
        <div class="card_content">
          <h2 class="card_title">Promote Independent Learning</h2>
          <p class="card_text"><br>To help students be able independent thinking &amp; learning</p>
        </div>
      </div>
    </li>
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=390"></div>
        <div class="card_content">
          <h2 class="card_title">Respect Individual Differences</h2>
          <p class="card_text"><br>Respect each other. Become your most unique self， you are the best</p>
        </div>
      </div>
    </li>
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=180"></div>
        <div class="card_content">
          <h2 class="card_title">Provide Personalize Instruction</h2>
          <p class="card_text"><br>Provide a teaching method that works for your students</p>
        </div>
      </div>
    </li>
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=201"></div>
        <div class="card_content">
          <h2 class="card_title">Effiency Learning</h2>
          <p class="card_text"><br>The EID audio-visual learning approach is effective at capturing students' interest</p>
        </div>
      </div>
    </li>
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=341"></div>
        <div class="card_content">
          <h2 class="card_title">User-Friendly</h2>
          <p class="card_text"><br>Improve user-accessibility and time flexibility to engage learners in the learning process</p>
        </div>
      </div>
    </li>
    <li class="cards_item">
      <div class="card">
        <div class="card_image"><img class="img_headings" src="https://picsum.photos/500/300/?image=5"></div>
        <div class="card_content">
          <h2 class="card_title">Innovation</h2>
          <p class="card_text"><br>Using a designated teaching model to ensure quality assurance</p>
        </div>
      </div>
    </li>
  </ul>
</div>
</section>

<section>
	<h1 class="heading"></h1>	
    <div>
		<h2 style="color: 001A1D;font-size: 3rem;">WELCOME TO EID!!</h2>
		<p id="home_intro" style="font-size: 2rem;"><br>EID promotes inclusivity by providing a level playing field for students with disabilities, allowing them to participate fully in the learning experience.
		EID promotes independence by enabling students to take control of their own learning, access resources independently, and work at their own pace without feeling rushed or pressured</p>
	</div>
	<h1 class="heading"></h1>
</section>


<section>
	<h1 class="heading"><br>Our Location</h1>

	<div class="map-responsive">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.146627454418!2d101.69837271475707!3d3.055405697774977!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4abb795025d9%3A0x1c37182a714ba968!2z5Lqa5aSq56eR5oqA5aSn5a2m!5e0!3m2!1szh-CN!2smy!4v1676125633576!5m2!1szh-CN!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
</section>


<section class="quick-select">

   <h1 class="heading">Quick Options</h1>

   <div class="box-container">

      <?php
         if($user_id != ''){
      ?>
      <div class="box">
         <h3 class="title">Likes and Comments</h3>
         <p>Total Likes : <span><?= $total_likes; ?></span></p>
         <a href="likes.php" class="inline-btn">view Likes</a>
         <p>Total Comments : <span><?= $total_comments; ?></span></p>
         <a href="comments.php" class="inline-btn">View Comments</a>
         <p>Saved Courses : <span><?= $total_bookmarked; ?></span></p>
         <a href="bookmark.php" class="inline-btn">View Bookmark</a>
      </div>
      <?php
         }else{ 
      ?>
      <div class="box" style="text-align: center;">
         <h3 class="title">Please Login or Register</h3>
          <div class="flex-btn" style="padding-top: .5rem;">
            <a href="login.php" class="option-btn">Login</a>
            <a href="register.php" class="option-btn">Register</a>
         </div>
      </div>
      <?php
      }
      ?>

      <div class="box">
         <h3 class="title">Learn More About Us</h3>
         <div class="flex">
            <a href="home.php"><i class="fas fa-house"></i><span>Home</span></a>
            <a href="about.php"><i class="fas fa-user"></i><span>About Us</span></a>
            <a href="courses.php"><i class="fas fa-book"></i><span>Course</span></a>
            <a href="teachers.php"><i class="fas fa-chalkboard-user"></i><span>Teachers</span></a>
            <a href="contact.php"><i class="fas fa-phone"></i><span>Contact Us</span></a>
            <!-- <a href="search_course.php"><i class="fas fa-camera"></i><span>Photography</span></a>
            <a href="search_course.php"><i class="fas fa-cog"></i><span>Software</span></a>
            <a href="search_course.php"><i class="fas fa-vial"></i><span>Science</span></a>-->
         </div>
      </div>

      <div class="box">
         <h3 class="title">Popular Topics</h3>
         <div class="flex">
            <a href="search_course.php"><i class="fas fa-pen"></i><span>Maths</span></a>
            <!-- <a href="search_course.php"><i class="fab fa-css3"></i><span>CSS</span></a>
            <a href="search_course.php"><i class="fab fa-js"></i><span>Javascript</span></a>
            <a href="search_course.php"><i class="fab fa-react"></i><span>React</span></a>
            <a href="search_course.php"><i class="fab fa-php"></i><span>PHP</span></a>
            <a href="search_course.php"><i class="fab fa-bootstrap"></i><span>Bootstrap</span></a>-->
         </div>
      </div>

      

   </div>

</section>

<!-- quick select section ends -->

<!-- courses section starts  -->

<?php
         if($user_id != ''){
      ?>
<section class="courses">

   <h1 class="heading">Latest Courses</h1>

   <div class="box-container">

      <?php
         $select_courses = $conn->prepare("SELECT * FROM `playlist` WHERE status = ? ORDER BY date DESC LIMIT 6");
         $select_courses->execute(['active']);
         if($select_courses->rowCount() > 0){
            while($fetch_course = $select_courses->fetch(PDO::FETCH_ASSOC)){
               $course_id = $fetch_course['id'];

               $select_tutor = $conn->prepare("SELECT * FROM `tutors` WHERE id = ?");
               $select_tutor->execute([$fetch_course['tutor_id']]);
               $fetch_tutor = $select_tutor->fetch(PDO::FETCH_ASSOC);
      ?>
      <div class="box">
         <div class="tutor">
            <img src="uploaded_files/<?= $fetch_tutor['image']; ?>" alt="">
            <div>
               <h3><?= $fetch_tutor['name']; ?></h3>
               <p><i class="fas fa-calendar"></i><span><?= $fetch_course['date']; ?></span></p>
               <p><i class="fas fa-sack-dollar"></i><span><?= $fetch_course['price']; ?></span></p>
            </div>
         </div>
         <img src="uploaded_files/<?= $fetch_course['thumb']; ?>" class="thumb" alt="">
         <h3 class="title"><?= $fetch_course['title']; ?></h3>
         <a href="playlist.php?get_id=<?= $course_id; ?>" class="inline-btn">view Course</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">No courses added yet!</p>';
      }
      ?>

   </div>

   <div class="more-btn">
      <a href="courses.php" class="inline-option-btn">view More</a>
   </div>

</section>


<?php
      }
      ?>
<!-- courses section ends -->











<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>