<?php
include_once('components/connect.php');

if(isset($_POST['ID']) && isset($_POST['Course']) && isset($_POST['Date']) && isset($_POST['Price'])){
    $ID = $_POST['ID'];
    $ID = filter_var($ID, FILTER_SANITIZE_STRING);
    $Date = $_POST['Date'];
    $Date = filter_var($Date, FILTER_SANITIZE_STRING);
    $Course = $_POST['Course'];
    $Course = filter_var($Course, FILTER_SANITIZE_STRING);
    $Price = $_POST['Price'];
    $Price = filter_var($Price, FILTER_SANITIZE_STRING);

   $add_payment = $conn->prepare("INSERT INTO `payment`(id, date, course_name, price) VALUES(?,?,?,?)");
   $add_payment->execute([$ID, $Date, $Course, $Price]);

   $message = 'Payment Record Created!';  
echo json_encode($message);
}
?>