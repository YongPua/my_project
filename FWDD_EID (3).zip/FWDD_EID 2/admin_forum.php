<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<?php

include 'components/admin_header.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin_Forum</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
	<style>
		#comments-container {
		  width: 80%;
		  margin: auto;
		  text-align: center;
		}

		#comments-list {
		  list-style-type: none;
		  margin: 0;
		  padding: 0;
		}

		#comment-input {
		  width: 80%;
		  padding: 10px;
		  margin: 10px 0;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		}

		#comment-submit-btn {
		  background-color: #4CAF50;
		  color: white;
		  padding: 10px;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}

		.announcecon{
			background-color:white;
			border-radius:10px;
			color:black;
			box-shadow: 13px 13px 20px grey, -13px -13px 20px white;
		}

		.announceprofile{
			background-color:grey;
			margin:auto;
			border-radius:50px;
			height:70px;
			width:70px;
			box-shadow:3px 3px 3px grey
		}

		.announceprofile svg{
			color:white;
			width:40px;
			height:40px;
			margin: 13px 15px 10px 14px;
		}

		.profilename{
			text-align:center;
			margin-left:auto;
			margin-right:auto;
		}

		.profilename a{
			color:grey;
		}

		#container {
		  display: flex;
		  justify-content: space-between;
		  align-items: flex-start;
		  width: 100%;
		  max-width: 960px;
		  margin: 0 auto;
		  padding: 20px;
		}

		@media only screen and (max-width: 768px) {
		  #container {
			flex-direction: column;
			align-items: center;
			padding: 10px;
		  }
		  
		  .announcecon td {
			width: 100%;
		  }
		  
		  .announceprofile {
			margin-bottom: 10px;
		  }
		  
		  .profilename {
			text-align: center;
		  }
		}

		/* CSS for mobile screens */
		@media only screen and (max-width: 480px) {
		  .announcecon td {
			display: block;
			width: 100%;
		  }
		  
		  .announceprofile {
			margin-bottom: 10px;
		  }
		  
		  .profilename {
			text-align: center;
		  }
		}
	.paragrapgh{
		font-size:13px;		
	}
	
	.announce_title{
		font-size:18px;
	}
	
	</style>
</head>
<body>

<!-- about section starts  -->

	<section>
		<div id="container">	
			<div class="announcecon">
				<table style="width: 100%">
					<tr>
						<td style="width: 136px" class="auto-style1">
							<br/><br/>
							<div class="announceprofile">
								<svg class="svg-icon" viewBox="0 0 20 20">
								<path d="M12.075,10.812c1.358-0.853,2.242-2.507,2.242-4.037c0-2.181-1.795-4.618-4.198-4.618S5.921,4.594,5.921,6.775c0,1.53,0.884,3.185,2.242,4.037c-3.222,0.865-5.6,3.807-5.6,7.298c0,0.23,0.189,0.42,0.42,0.42h14.273c0.23,0,0.42-0.189,0.42-0.42C17.676,14.619,15.297,11.677,12.075,10.812 M6.761,6.775c0-2.162,1.773-3.778,3.358-3.778s3.359,1.616,3.359,3.778c0,2.162-1.774,3.778-3.359,3.778S6.761,8.937,6.761,6.775 M3.415,17.69c0.218-3.51,3.142-6.297,6.704-6.297c3.562,0,6.486,2.787,6.705,6.297H3.415z"></path>
								</svg> 
							</div>
							<br/>
							<div class="profilename">
								<b><a href="#">Stephen</a></b>
								<br/>
								<p>28 DEC 22 <br/> 10AM</p>
							</div>
						</td>
						<td style="width: 656px" class="auto-style1">
							<h2 class="announce_title">Course Videos Uploaded</h2>
								<details>
									<summary style="font-size:15px;">View Details</summary>
									<p class="paragrapgh">Dear Student, <br/><br/>Greeting from EID! <br/><br/>We have uploaded the course videos for your lesson.<br/>
										<br/>Date :   28th December 2022, Wednesday<br/>
										Time :   10.00 AM<br/><br/>
										You will need to enter to the course page to view your videos. <br/><br/>Thank you.</p>
									<div id="comments-container">
									  <h2>Comments</h2>
									  <ul id="comments-list">
									  </ul>
									  <form id="comment-form">
										<input type="text" id="comment-input" placeholder="Type your comment here">
										<button type="submit" id="comment-submit-btn">Comment</button>
									  </form>
									</div>
								</details>
						</td>
					</tr>
					<tr>
						<td style="width: 136px" class="auto-style1">
							<br/><br/>
							<div class="announceprofile">
								<svg class="svg-icon" viewBox="0 0 20 20">
								<path d="M12.075,10.812c1.358-0.853,2.242-2.507,2.242-4.037c0-2.181-1.795-4.618-4.198-4.618S5.921,4.594,5.921,6.775c0,1.53,0.884,3.185,2.242,4.037c-3.222,0.865-5.6,3.807-5.6,7.298c0,0.23,0.189,0.42,0.42,0.42h14.273c0.23,0,0.42-0.189,0.42-0.42C17.676,14.619,15.297,11.677,12.075,10.812 M6.761,6.775c0-2.162,1.773-3.778,3.358-3.778s3.359,1.616,3.359,3.778c0,2.162-1.774,3.778-3.359,3.778S6.761,8.937,6.761,6.775 M3.415,17.69c0.218-3.51,3.142-6.297,6.704-6.297c3.562,0,6.486,2.787,6.705,6.297H3.415z"></path>
								</svg> 
							</div>
							<br/>
							<div class="profilename">
								<b><a href="#">Sarah</a></b>
								<br/>
								<p>10 Jan 23 <br/> 3PM</p>
							</div>
						</td>
						<td style="width: 656px" class="auto-style1">
							<h2 class="announce_title">Technical Issues In Watch Videos</h2>
								<details>
									<summary style="font-size:15px;">View Details</summary>
									<p class="paragrapgh">Dear Student, <br/><br/>Greeting from EID! <br/><br/>We will be performing maintenance tomorrow from 12AM to 10PM so some features will not be available.
									<br/><br/>We apologize for any inconvenience.<br/><br/>Thank you.</p><div id="comments-container">
									  <h2>Comments</h2>
									  <ul id="comments-list">
									  </ul>
									  <form id="comment-form">
										<input type="text" id="comment-input" placeholder="Type your comment here">
										<button type="submit" id="comment-submit-btn">Comment</button>
									  </form>
									</div>
								</details>
						</td>
					</tr>
					<tr>
						<td style="width: 136px" class="auto-style1">
							<br/><br/>
							<div class="announceprofile">
								<svg class="svg-icon" viewBox="0 0 20 20">
								<path d="M12.075,10.812c1.358-0.853,2.242-2.507,2.242-4.037c0-2.181-1.795-4.618-4.198-4.618S5.921,4.594,5.921,6.775c0,1.53,0.884,3.185,2.242,4.037c-3.222,0.865-5.6,3.807-5.6,7.298c0,0.23,0.189,0.42,0.42,0.42h14.273c0.23,0,0.42-0.189,0.42-0.42C17.676,14.619,15.297,11.677,12.075,10.812 M6.761,6.775c0-2.162,1.773-3.778,3.358-3.778s3.359,1.616,3.359,3.778c0,2.162-1.774,3.778-3.359,3.778S6.761,8.937,6.761,6.775 M3.415,17.69c0.218-3.51,3.142-6.297,6.704-6.297c3.562,0,6.486,2.787,6.705,6.297H3.415z"></path>
								</svg> 
							</div>
							<br/>
							<div class="profilename">
								<b><a href="#">Tan</a></b>
								<br/>
								<p>25 Feb 23 <br/> 9AM</p>
							</div>
						</td>
						<td style="width: 656px" class="auto-style1">
							<h2 class="announce_title">New Course Coming Soon</h2>
								<details>
									<summary style="font-size:15px;">View Details</summary>
									<p class="paragrapgh">Dear Student, <br/><br/>Greeting from EID! <br/><br/>We will upload the new course once students have completed their lessons.
								<br/><br/>Thank you.</p><div id="comments-container">
									  <h2>Comments</h2>
									  <ul id="comments-list">
									  </ul>
									  <form id="comment-form">
										<input type="text" id="comment-input" placeholder="Type your comment here">
										<button type="submit" id="comment-submit-btn">Comment</button>
									  </form>
									</div>
								</details>
						</td>
					</tr>
					</table>
			</div>
		</div>
	</section>


	<?php include 'components/footer.php'; ?>

	<!-- custom js file link  -->
	<script src="js/script.js"></script>
	   
	<script>
		const commentForm = document.getElementById('comment-form');
		const commentInput = document.getElementById('comment-input');
		const commentsList = document.getElementById('comments-list');

		commentForm.addEventListener('submit', (event) => {
		  event.preventDefault();
		  const comment = commentInput.value.trim();
		  if (comment !== '') {
			const newComment = document.createElement('li');
			newComment.textContent = comment;
			commentsList.appendChild(newComment);
			commentInput.value = '';
		  }
		});
	</script>

</body>
</html>