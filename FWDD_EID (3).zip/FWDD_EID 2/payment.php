<?php
include_once('components/connect.php');
if(isset($_COOKIE['user_id'])){
  $user_id = $_COOKIE['user_id'];
}else{
  $user_id = '';
}

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $getCourse = $conn->prepare("SELECT * FROM `course` WHERE id = ?");
  $getCourse->execute([$id]);
  $row = $getCourse->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <title>Payment Page</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
  <style>
    /* Style for the content box */
    .content-box {
      border-radius: 15px;
      box-shadow: 0px 5px 5px 5px lightgray;
      display: flex;
      margin: 50px auto;
      max-width: 1200px;
      padding: 30px;
    }

    /* Style for the left side of the content box */
    .content-box-left {
      background-color: #40AAD0;
      color: white;
      flex: 1;
      padding: 10px;
      border-radius: 15px;
      height: 420px;
    }

    /* Style for the right side of the content box */
    .content-box-right {
      background-color: white;
      flex: 2;
      padding: 10px;
    }

    /* Style for the receipt section */
    .receipt {
      margin-top: 20px;
    }

    /* Style for the invoice table */
    table {
      border-collapse: collapse;
      margin-top: 20px;
      width: 100%;
    }

    /* Style for the invoice table cells */
    td {
      border: 1px solid black;
      padding: 8px;
      text-align: left;
      vertical-align: top;
    }

    button[type="button"] {
      background-color: #40AAD0;
      color: white;
      border: none;
      padding: 10px 20px;
      margin: 20px 10px;
      font-size: 16px;
      cursor: pointer;
      border-radius: 4px;
      float: right;
    }

    button[type="button"]:hover {
      background-color: #006080;
    }
  </style>
</head>
<?php include_once("components/user_header.php"); ?>
<body>
  <form action="" method="POST" enctype="multipart/form-data">

    <?php
    $myDate = date('Y-m-d');
    $myCourse = 'Math Level 1';
    $myID;
    $myPrice = '100';
    ?>
    
    <div class="content-box">
      <div class="content-box-left" style="line-height:1.5; font-size:18px">
        <p><strong>Confirmation ID:</strong><br> <span id="confirmation-id" name="id"><?php echo $myID; ?></span></p>
        <p><strong>Date:</strong><br> <span id="date" name="date"><?php echo $myDate; ?></span></p>
        <p name="course_name"><strong>Course:</strong><br> <span id="course_name"><?php echo $row['course_name']; ?></span></p>
        <p name="price"><strong>Price:</strong><br><span id="price">$<?php echo $row['price']; ?></span> </p>
        <img src="<?php echo $row['course_picture']; ?>" alt="<?php echo $row['course_name']; ?>" width="100px" height="100px">
      </div>
      <div class="content-box-right">
        <h2>View of Your Receipt</h2>
        <p>Dear customer,</p>
        <p>You have made a payment on the current course <?php echo $row['course_name']; ?>, with the price $<?php echo $row['price']; ?> for your child. Kindly check your email after you have checkout this payment page.</p>
        <p>Thank you.</p>
        <div class="receipt">
          <label for="payment-method">Select your payment method:</label>
          <select id="payment-method" name="payment-method">
            <option value="online-banking" name="online-banking">Online banking</option>
            <option value="touch-n-go" name="touch-n-go">Touch n Go ewallet</option>
            <option value="credit-card" name="credit-card">Credit or Debit Card</option>
          </select>
          

          <table>
            <tr>
              <td><strong>Item</strong></td>
              <td><strong>Price</strong></td>
            </tr>
            <tr>
              <td><?php echo $row['course_name']; ?></td>
              <td>$<?php echo $row['price']; ?></td>
            </tr>
          </table>
          <p>Total: $<?php echo $row['price']; ?></p>
          <button id="checkout-button" type="button" name="submit" onclick="submitpayment()">Checkout</button>
        </div>
      </div>
    </div>
  </form>
  <script>
    function submitpayment() {
      var myID = $("#confirmation-id").text();
      var myCourse = $("#course_name").text();
      var myDate = $("#date").text();
      var myPrice = $("#price").text();
      console.log(myID);
      console.log(myCourse);
      console.log(myDate);
      console.log(myPrice);

      $.ajax({
        url: "payment_operation.php",
        method: "POST",
        data: {
          ID: myID,
          Course: myCourse,
          Date: myDate,
          Price: myPrice
        },
        dataType: "json",
        success: function(response) {
          alert(response);

        },
        error: function(response) {
          console.log(response);
        }
      });
    }

    // const checkoutButton = document.getElementById("checkout-button");
    // checkoutButton.addEventListener("click", function() {
    //   alert("The system will bring you to the payment gateway soon.");
    // });

    // Generate confirmation ID and store it in sessionStorage
    if (!sessionStorage.getItem('confirmationID')) {
      const confirmationID = Math.floor(Math.random() * 100000);
      sessionStorage.setItem('confirmationID', confirmationID);
    }

    // Retrieve confirmation ID from sessionStorage and display it on the page
    const confirmationIDElement = document.getElementById('confirmation-id');
    confirmationIDElement.textContent = sessionStorage.getItem('confirmationID');

    // Display current date and time on the page
    const dateElement = document.getElementById('date');
    const currentDate = new Date();
    dateElement.textContent = currentDate.toLocaleString();

    // Other JavaScript code for handling payment and checkout goes here
  </script>