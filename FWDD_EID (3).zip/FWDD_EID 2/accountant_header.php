<?php
if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}
?>

<header class="header">

   <section class="flex">

      <a href="home.php"><img src="images/eid-logo.png" alt="eid-logo"></a>
      
      <form action="search_course.php" method="post" class="search-form">
         <input type="text" name="search_course" placeholder="Search courses..." required maxlength="100">
         <button type="submit" class="fas fa-search" name="search_course_btn"></button>
      </form>

      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="search-btn" class="fas fa-search"></div>
         <div id="user-btn" class="fas fa-user"></div>
         <div id="toggle-btn" class="fas fa-sun"></div>
      </div>

      <div class="profile">
         <?php
            $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
            $select_profile->execute([$user_id]);
            if($select_profile->rowCount() > 0){
            $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
         ?>
         <img src="uploaded_files/<?= $fetch_profile['image']; ?>" alt="">
         <h3><?= $fetch_profile['name']; ?></h3>
         <span>Student</span>
         <a href="profile.php" class="btn">View Profile</a>
         <a href="components/user_logout.php" onclick="return confirm('Log out from user website?');" class="delete-btn">Logout</a>
         <?php
            }else{
         ?>
         <h3>Please Login or Register</h3>
          <div class="flex-btn">
            <a href="login.php" class="option-btn">login</a>
            <a href="register.php" class="option-btn">register</a>
         </div>
         <?php
            }
         ?>
      </div>

   </section>

</header>

<!-- header section ends -->

<!-- side bar section starts  -->

<div class="side-bar" style="overflow: auto;">

   <div class="close-side-bar">
      <i class="fas fa-times"></i>
   </div>

   <nav class="navbar">
      <a href=""><i class="fas fa-address-card"></i><span>Profile</span></a>
      <a href=""><i class="fas fa-money-check-dollar"></i><span>Payroll</span></a>
      <a href=""><i class="fas fa-money-bill"></i><span>Course Sales</span></a>
      <a href=""><i class="fas fa-credit-card"></i><span>Customer</span></a>
   </nav>

</div>