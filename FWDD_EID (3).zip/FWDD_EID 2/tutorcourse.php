<?php
include_once("components/connect.php");

if(isset($_COOKIE['user_id'])){
  $user_id = $_COOKIE['user_id'];
  }else{
  $user_id = '';header('location:login.php');
}

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $getCourse = $conn->prepare("SELECT * FROM course WHERE id = ?");
  $getCourse->execute([$id]);
  $row = $getCourse->fetch(PDO::FETCH_ASSOC);
   
  if(isset($_POST['add_comment'])){

    if($user_id != ''){
 
       $id = unique_id();
       $comment_box = $_POST['comment_box'];
       $comment_box = filter_var($comment_box, FILTER_SANITIZE_STRING);
       $content_id = $_POST['content_id'];
       $content_id = filter_var($content_id, FILTER_SANITIZE_STRING);
 
       $select_content = $conn->prepare("SELECT * FROM `content` WHERE id = ? LIMIT 1");
       $select_content->execute([$content_id]);
       $fetch_content = $select_content->fetch(PDO::FETCH_ASSOC);
 
       $tutor_id = $fetch_content['tutor_id'];
 
       if($select_content->rowCount() > 0){
 
          $select_comment = $conn->prepare("SELECT * FROM comments WHERE content_id = ? AND user_id = ? AND tutor_id = ? AND comment = ?");
          $select_comment->execute([$content_id, $user_id, $tutor_id, $comment_box]);
 
          if($select_comment->rowCount() > 0){
             $message[] = 'Comment already added!';
          }else{
             $insert_comment = $conn->prepare("INSERT INTO comments(id, content_id, user_id, tutor_id, comment) VALUES(?,?,?,?,?)");
             $insert_comment->execute([$id, $content_id, $user_id, $tutor_id, $comment_box]);
             $message[] = 'New comment added!';
          }
 
       }else{
          $message[] = 'Something went wrong!';
       }
 
    }else{
       $message[] = 'Please login first!';
    }
 
 }
 
 if(isset($_POST['delete_comment'])){
 
    $delete_id = $_POST['comment_id'];
    $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING);
 
    $verify_comment = $conn->prepare("SELECT * FROM comments WHERE id = ?");
    $verify_comment->execute([$delete_id]);
 
    if($verify_comment->rowCount() > 0){
       $delete_comment = $conn->prepare("DELETE FROM comments WHERE id = ?");
       $delete_comment->execute([$delete_id]);
       $message[] = 'Comment deleted successfully!';
    }else{
       $message[] = 'Comment already deleted!';
    }
 
 }
 
 if(isset($_POST['update_now'])){
 
    $update_id = $_POST['update_id'];
    $update_id = filter_var($update_id, FILTER_SANITIZE_STRING);
    $update_box = $_POST['update_box'];
    $update_box = filter_var($update_box, FILTER_SANITIZE_STRING);
 
    $verify_comment = $conn->prepare("SELECT * FROM comments WHERE id = ? AND comment = ?");
    $verify_comment->execute([$update_id, $update_box]);
 
    if($verify_comment->rowCount() > 0){
       $message[] = 'comment already added!';
    }else{
       $update_comment = $conn->prepare("UPDATE comments SET comment = ? WHERE id = ?");
       $update_comment->execute([$update_box, $update_id]);
       $message[] = 'comment edited successfully!';
    }
 
 }
}
?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Tutor's Course</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<style>
  body {
    margin: 0;
    padding: 0;
    font-family: 'Times New Roman', Times, serif;
    line-height: 1.5;
  }

  .course-info {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    margin-top: 50px;
    border: 1px solid #ccc;
    border-radius: 20px;
    padding: 20px;
    background-color: white;
    box-shadow: 0px 3px 3px 3px lightgray;
    height: 400px;
  }

  .course-image {
    flex-basis: 30%;
    margin-right: 20px;
    background-color: grey;
    width: 380px;
    height: 380px;
  }

  .course-video {
    margin: 50px;
    align-items: center;
    display: flex;
    justify-content: center;

  }

  .course-details {
    flex-basis: 60%;
  }

  .course-name {
    font-size: 36px;
    margin: 0;
  }

  .course-description {
    font-size: 18px;
    margin-top: 10px;
  }

  .course-price {
    font-size: 24px;
    margin-top: 10px;
  }

  .course-content {
    margin: 0px 80px;
  }

  .tutor-profile {
    margin: 0px 80px;
  }

  button[type="button"] {
    background-color: #40AAD0;
    color: white;
    border: none;
    padding: 10px 20px;
    margin: 20px 10px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 4px;
    float: right;
    height: 50px;
  }

  button[type="button"]:hover {
    background-color: #006080;
  }
</style>

<body>
  <?php include 'components/user_header.php' ?>
    <div class="course-info">
      <img class="course-image" src="<?php echo $row['course_picture']; ?>" alt="Math Course">
      <div class="course-details">
        <h1 class="course-name"><?php echo $row['course_name']; ?></h1>
        <p class="course-description"><?php echo $row['description']; ?></p>
        <p class="instructor-name"><?php echo $row['instructor_name']; ?></p>
        <p class="course-price">RM<?php echo $row['price']; ?></p>
        <button type="button"><a href="payment.php?id=<?php echo $row['id']; ?>" class="enroll-button">Enroll Now</a></button>
        <?php if(isset($_COOKIE['tutor_id'])){?>
               <button type="button"><a href="tutor/courses_editing.php?id=<?php echo $row['id']; ?>" class="edit-button">Edit Course</a></button>
                  <?php
                  }
                  ?>
      </div>
    </div>

    <div class="course-video">
    <iframe width="700" height="500" src="<?php echo $row['content']; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  </div>
  <div class="course-content">
    <h2>You'll learn:</h2>
    <ul class="course-topics">
      <li><?php echo $row['you_learn']; ?></li>
    </ul>
  </div>

<?php
   if(isset($_POST['edit_comment'])){
      $edit_id = $_POST['comment_id'];
      $edit_id = filter_var($edit_id, FILTER_SANITIZE_STRING);
      $verify_comment = $conn->prepare("SELECT * FROM `comments` WHERE id = ? LIMIT 1");
      $verify_comment->execute([$edit_id]);
      if($verify_comment->rowCount() > 0){
         $fetch_edit_comment = $verify_comment->fetch(PDO::FETCH_ASSOC);
?>
<section class="edit-comment">
   <h1 class="heading">edti comment</h1>
   <form action="" method="post">
      <input type="hidden" name="update_id" value="<?= $fetch_edit_comment['id']; ?>">
      <textarea name="update_box" class="box" maxlength="1000" required placeholder="Please enter your comment" cols="30" rows="10"><?= $fetch_edit_comment['comment']; ?></textarea>
      <div class="flex">
         <a href="watch_video.php?get_id=<?= $get_id; ?>" class="inline-option-btn">Cancel Edit</a>
         <input type="submit" value="update" name="update_now" class="inline-btn">
      </div>
   </form>
</section>
<?php
   }else{
      $message[] = 'comment was not found!';
   }
}
?>

<!-- comments section starts  -->

<section class="comments">

   <h1 class="heading">Add a Comment</h1>

   <form action="" method="post" class="add-comment">
      <input type="hidden" name="content_id" value="<?= $get_id; ?>">
      <textarea name="comment_box" required placeholder="Write your comment..." maxlength="1000" cols="30" rows="10"></textarea>
      <input type="submit" value="add comment" name="add_comment" class="inline-btn">
   </form>

   <h1 class="heading">User Comments</h1>

   
   <div class="show-comments">
      <?php
         $select_comments = $conn->prepare("SELECT * FROM `comments` WHERE content_id = ?");
         $select_comments->execute([$get_id]);
         if($select_comments->rowCount() > 0){
            while($fetch_comment = $select_comments->fetch(PDO::FETCH_ASSOC)){   
               $select_commentor = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
               $select_commentor->execute([$fetch_comment['user_id']]);
               $fetch_commentor = $select_commentor->fetch(PDO::FETCH_ASSOC);
      ?>
      <div class="box" style="<?php if($fetch_comment['user_id'] == $user_id){echo 'order:-1;';} ?>">
         <div class="user">
            <img src="uploaded_files/<?= $fetch_commentor['image']; ?>" alt="">
            <div>
               <h3><?= $fetch_commentor['name']; ?></h3>
               <span><?= $fetch_comment['date']; ?></span>
            </div>
         </div>
         <p class="text"><?= $fetch_comment['comment']; ?></p>
         <?php
            if($fetch_comment['user_id'] == $user_id){ 
         ?>
         <form action="" method="post" class="flex-btn">
            <input type="hidden" name="comment_id" value="<?= $fetch_comment['id']; ?>">
            <button type="submit" name="edit_comment" class="inline-option-btn">Edit Comment</button>
            <button type="submit" name="delete_comment" class="inline-delete-btn" onclick="return confirm('Delete this comment?');">Delete Comment</button>
         </form>
         <?php
         }
         ?>
      </div>
      <?php
       }
      }else{
         echo '<p class="empty">No comments added yet!</p>';
      }
      ?>
      </div>

  <?php include 'components/footer.php'?>
  
</body>

</html>