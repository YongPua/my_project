<?php

	include 'components/connect.php';

	if(isset($_COOKIE['user_id'])){
	   $user_id = $_COOKIE['user_id'];
	}else{
	   $user_id = '';
	}

	
	
	// prepare and execute SQL query to select all data from payment table
	$stmt = $conn->prepare("SELECT course_name, SUM(CAST(REPLACE(price, '$', '') AS DECIMAL(10,2))) AS total_price FROM payment GROUP BY course_name;");
	$stmt->execute();
	$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>AccountantAdmin__CourseSalesList</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
	<style>
	.pr_container {
		margin: 0 auto;
		padding: 20px;
		max-width: 600px;
	}

	#pr_h1 {
		text-align: center;
		font-size:20px;
	}

	#payroll-form {
		display: flex;
		flex-direction: column;
	}

	#employee-name, #payroll, #month {
		padding: 5px;
		border-radius: 5px;
		border: 1px solid #ccc;
		margin-bottom: 10px;
	}

	#error-msg {
		color: red;
	}

	#payroll-table {
		margin-top: 20px;
		border-collapse: collapse;
		width: 100%;
	}

	#payroll-table th, #payroll-table td {
		padding: 8px;
		text-align: left;
		border: 1px solid #ddd;
	}

	#payroll-table th {
		background-color: #f2f2f2;
		color: #333;
		font-weight: bold;
	}

	#payroll-table th, #payroll-table td {
	  font-size: 13px;
	}

	</style>
</head>
<body>

	<?php include 'components/accountant_header.php'; ?>

	<!-- about section starts  -->
	<section>
		<h1 class="heading">Welcome to EID Course Sales List Page</h1>

		<div class="pr_container">
			<h1 id="pr_h1" >Course Sales List</h1>
			
			<table id="payroll-table">
				<thead>
					<tr>
						<th>Course_Name</th>
						<th>Price (RM)</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($rows as $row): ?>
						<tr>
							<td><?= $row['course_name'] ?></td>
							<td><?= $row['total_price'] ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<div id="result"></div>
		</div>
	</section>

	<!-- reviews section ends -->

	<?php include 'components/footer.php'; ?>

	<!-- custom js file link  -->
	<script src="js/script.js"></script>

   
</body>
</html>