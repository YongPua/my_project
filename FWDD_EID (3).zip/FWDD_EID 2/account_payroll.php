<?php

	include 'components/connect.php';

	if(isset($_COOKIE['user_id'])){
	   $user_id = $_COOKIE['user_id'];
	}else{
	   $user_id = '';
	}

	// check if form has been submitted
if (isset($_POST['employee_name']) && isset($_POST['payroll']) && isset($_POST['month'])) {
  // retrieve form data
  $employee_name = $_POST['employee_name'];
  $payroll = $_POST['payroll'];
  $month = $_POST['month'];

  // validate form data
  if (empty($employee_name) || empty($payroll) || empty($month)) {
    $error_msg = "Please fill in all the fields.";
  } else {
    // prepare and execute SQL query to insert data into payroll table
    $stmt = $conn->prepare("INSERT INTO payroll (Employee, Payroll,Month) VALUES (:employee_name, :payroll, :month)");
    $stmt->bindParam(":employee_name", $employee_name);
    $stmt->bindParam(":payroll", $payroll);
	$stmt->bindParam(":month", $month);
    $stmt->execute();
	
  }
}
	
		// prepare and execute SQL query to select all data from payroll table
	$stmt = $conn->prepare("SELECT * FROM payroll");
	$stmt->execute();

	// fetch all rows and store in a variable
	$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>



<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Accountant_Payroll</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
	<style>
	.pr_container {
		margin: 0 auto;
		padding: 20px;
		max-width: 600px;
	}

	#pr_h1 {
		text-align: center;
		font-size:20px;
	}

	#payroll-form {
		display: flex;
		flex-direction: column;
	}

	.lbl_pr {
		margin-top: 10px;
		font-size:12px;
	}

	#employee-name, #payroll, #month {
		padding: 5px;
		border-radius: 5px;
		border: 1px solid #ccc;
		margin-bottom: 10px;
	}

	#pr_submit {
		background-color: #4CAF50;
		color: white;
		padding: 10px 20px;
		border: none;
		border-radius: 5px;
		cursor: pointer;
		margin-top: 10px;
	}

	#pr_submit:hover {
		background-color: #3e8e41;
	}

	#error-msg {
		color: red;
	}

	#payroll-table {
		margin-top: 20px;
		border-collapse: collapse;
		width: 100%;
	}

	#payroll-table th, #payroll-table td {
		padding: 8px;
		text-align: left;
		border: 1px solid #ddd;
	}

	#payroll-table th {
		background-color: #f2f2f2;
		color: #333;
		font-weight: bold;
	}

	#payroll-table th, #payroll-table td {
	  font-size: 13px;
	}

	</style>
</head>
<body>

	<?php include 'components/accountant_header.php'; ?>

	<!-- about section starts  -->
	<section>
		<h1 class="heading">Welcome to EID Accountant Payroll Page</h1>

		<div class="pr_container">
			<h1 id="pr_h1" >Payroll Management System</h1>
			
			<table id="payroll-table">
				<thead>
					<tr>
						<th>Employee Name</th>
						<th>Payroll</th>
						<th>Month</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($rows as $row): ?>
						<tr>
							<td><?= $row['Employee'] ?></td>
							<td><?= $row['Payroll'] ?></td>
							<td><?= $row['Month'] ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<form id="payroll-form"  action="account_payroll.php" method="post">
				<label class="lbl_pr" for="employee-name">Employee Name:</label>
				<input type="text" id="employee-name" name="employee_name"><br>

				<label class="lbl_pr" for="payroll">Payroll:</label>
				<input type="text" id="payroll" name="payroll"><br>
				
				<label class="lbl_pr" for="month">Month:</label>
				<input type="text" id="month" name="month"><br>

				<input id="pr_submit" type="submit" value="Submit">
			</form>

			<?php if(isset($error_msg)) { ?>
				<p id="error-msg"><?= $error_msg ?></p>
			<?php } ?>

			<div id="result"></div>
		</div>
	</section>

	<!-- reviews section ends -->

	<?php include 'components/footer.php'; ?>

	<!-- custom js file link  -->
	<script src="js/script.js"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		$(document).ready(function() {
		  $('#pr_submit').click(function() {
			var employee_name = $('#employee-name').val();
			var payroll = $('#payroll').val();
			var month = $('#month').val();

			if (employee_name !== '' && payroll !== '' && month !== '') {
			  alert('Thank you for submitting the payroll information.');
			}
		  });
		});
	</script>



   
</body>
</html>